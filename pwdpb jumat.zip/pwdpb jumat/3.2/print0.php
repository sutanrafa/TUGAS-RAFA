<?php
$teks= "smkn 2 padang";
echo "Belajar Web Programming di $teks";
?>