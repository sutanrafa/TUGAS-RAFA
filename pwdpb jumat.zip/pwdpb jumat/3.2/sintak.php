<?php
$teks= "USBI";
echo "mari kita belajar php";
?>