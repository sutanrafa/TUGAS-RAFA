<?php
print "Web programming","Dengan PHP";
?>