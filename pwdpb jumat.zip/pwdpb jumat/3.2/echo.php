<?php
echo "PemrogramanWeb";
echo "<p>";
echo ("Dengan PHP");
?>