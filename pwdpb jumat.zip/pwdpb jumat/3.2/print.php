<?php
print "Belajar PHP";
print "<p>";
print ("Cetak teks ke layar dengan PHP");
?>