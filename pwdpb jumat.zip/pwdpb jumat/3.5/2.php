<?php
$teks = "smk n2 padang";
echo "Saya belajar di ".$teks."<br>";
?>