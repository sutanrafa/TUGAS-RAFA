<?php
$c= true;
$d= false;
echo "Nilai c adalah : $c";
echo "<br>";
echo "Nilai d adalah : $d";
?>