<?php
$a= 30; 
echo $a;
?>