<?php
$c= 30;
$d= 2;
$x = $c - $d;
echo $x;
?>
