<?php
$nilai= 10.5;
echo $nilai;
?>