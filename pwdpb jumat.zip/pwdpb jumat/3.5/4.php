<?php
$teks = "mata pelajaran \"pwdpb\" ";
echo $teks;
?>