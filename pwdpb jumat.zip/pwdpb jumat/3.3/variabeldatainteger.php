<?php
$a = 2;
echo "smk n $a";
?>