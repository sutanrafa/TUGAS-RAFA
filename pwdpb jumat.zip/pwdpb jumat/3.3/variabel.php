<?php
$teks = "Contoh Assigment Operators";
echo $teks;
?>