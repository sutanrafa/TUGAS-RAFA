<?php
$teks = "fahri andoza putra";
echo $teks;
?>