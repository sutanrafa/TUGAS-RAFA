<?php
$teks = "smk n2";
echo "Saya belajar di ".$teks."<br>";
?>