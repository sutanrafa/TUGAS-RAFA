<?php
define ("prodi","Sistem Informasi");
echo prodi;
?>