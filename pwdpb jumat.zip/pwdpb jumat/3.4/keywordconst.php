<?php
const teks = "Saya belajar di smkn2 padang";
echo teks;
?>