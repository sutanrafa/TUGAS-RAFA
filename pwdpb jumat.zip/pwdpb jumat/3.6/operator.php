<?php
$a = 20;
$b = 14;
$penjumlahan = $a + $b;
$pengurangan = $a - $b;
$perkalian = $a * $b;
$pembagian = $a / $b;
$sisa_bagi = $a % $b; 
echo "Hasil Penjumlahan = ".$penjumlahan."<br>";
echo "Hasil Pengurangan = ".$pengurangan."<br>";
echo "Hasil Perkalian = ".$perkalian."<br>";
echo "Hasil Pembagian = ".$pembagian."<br>";
echo "Hasil Sisa Bagi = ".$sisa_bagi."<br>"; 
?>